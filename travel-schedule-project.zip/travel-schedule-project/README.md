# travel-schedule-project
## 개발환경
1. java 11
2. STS4
3. MySql
## 세팅
1. Spring Web
2. Lombok
3. Spring Security
4. Spring Data Jpa
5. Maven
