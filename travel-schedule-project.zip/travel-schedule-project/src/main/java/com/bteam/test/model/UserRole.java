package com.bteam.test.model;

public enum UserRole {

	USER,    //사용자
	ADMIN  // 관리자
}
